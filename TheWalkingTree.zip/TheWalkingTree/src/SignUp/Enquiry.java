package SignUp;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class Enquiry {

	WebDriver driver;
	
	
	public Enquiry(WebDriver driver) throws InterruptedException {
		Thread.sleep(3000);
		this.driver=driver;
	}

	public void clickenquiry() throws InterruptedException {

		Thread.sleep(3000);
		System.out.println("came to enquiry page");
	
		WebElement menu1 = driver.findElement(By.xpath("(//a[@data-tab='banquetes'])"));
		menu1.click();
		
		Thread.sleep(2000);

		System.out.println("finding sub menu");
		Thread.sleep(2000);
		WebElement submenu = driver.findElement(By.xpath("//div[@class='layoutNavMenuTabVenuesList']/ul/li[3]/a"));
		System.out.println("found sub menu");
		((JavascriptExecutor)driver).executeScript("arguments[0].click();",submenu);
		
		Thread.sleep(2000);  
		
		 JavascriptExecutor js = (JavascriptExecutor) driver;
	     js.executeScript("window.scrollBy(0,-1000)", "");
	       
		WebElement requestPrice = driver.findElement(By.xpath("//button[@data-storefront-id ='36423']"));
		System.out.println("found request pricing button");
		((JavascriptExecutor)driver).executeScript("arguments[0].click();",requestPrice);
		System.out.println("request price button clicked");
	
		Thread.sleep(2000);  
		WebElement sendButton = driver.findElement(By.xpath("//button[@type ='submit']"));
		System.out.println("found request pricing button");
		((JavascriptExecutor)driver).executeScript("arguments[0].click();",sendButton);
		System.out.println("Request send");
	}
}	
