package SignUp;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;






public class StepOne {
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Vishal Jagwani\\Downloads\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		ScreenRecorderUtil.startRecord("main");
		driver.get("https://www.weddingwire.in/");
		driver.manage().window().maximize();
		driver.findElement(By.linkText("FREE SIGN UP")).click();
				
		SignUpPage signUp= new SignUpPage(driver);
		Enquiry enquiry = new Enquiry(driver);
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		try {
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		signUp.insertusername();
		signUp.insertemail();
		signUp.insertpassword();
		signUp.insertlocation1();
		signUp.insertphone();
		signUp.userIdentity();
		signUp.insertDate();
		signUp.clicksubmit() ;
		Thread.sleep(3000);
		signUp.clickSave();
		Thread.sleep(3000);
		enquiry.clickenquiry();
		
			
		 System.out.println("Page navigated to: " +driver.getTitle());
	    driver.quit();
	    ScreenRecorderUtil.stopRecord();
	}	
	
	
		

	
}
