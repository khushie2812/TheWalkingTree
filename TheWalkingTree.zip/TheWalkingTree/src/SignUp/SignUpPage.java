package SignUp;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignUpPage {

		WebDriver driver;
		

		public SignUpPage(WebDriver driver) {
			this.driver=driver;
		}
		
		
		By username= By.className("textfield__input");
		By useremail =  By.xpath("//input[@placeholder='Email']");
		By userpassword = By.xpath("//input[@placeholder='Password']");
		
		String desiredOption = "Mumbai";
		By locText=By.cssSelector("#txtStrPoblacion");
		By eventDate= By.xpath("//div[@class='textfield storefront-contact-date app-common-datepicker']");
		
		By calender = By.xpath("//i[@class='textfield__icon icon icon-form-cal']");
		By userPhoneNumber = By.id("phoneFormSignUp");
	    By userIdentity= By.xpath(".//span[contains(.,' Bride ')]");
		By submit =  By.xpath("//button[@type='submit']");
		By save=By.xpath("//input[@value='Save']");
		
		public void insertusername() {
			driver.findElement(username).sendKeys("abc def");
		}
		
		public void insertemail() {
			
		        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		        StringBuilder salt = new StringBuilder();
		        Random rnd = new Random();
		        while (salt.length() < 10) { // length of the random string.
		            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
		            salt.append(SALTCHARS.charAt(index));
		        }
		        String saltStr = salt.toString();
		        driver.findElement(useremail).sendKeys( saltStr    +"@gmail.com");
		}
		
		public void insertpassword() {
			driver.findElement(userpassword).sendKeys("Tial12345");
		}
		public void insertlocation1() throws InterruptedException {
			WebElement locationInput= driver.findElement(locText);
			locationInput.sendKeys("Mum");
		    Thread.sleep(3000);
		    List<WebElement> options = driver.findElements(By.xpath("//li[@class='suggest-navigation']"));
		    for (WebElement option : options) {
	            if (option.getText().contains(desiredOption)) {
	            	option.click();
	                break;
	            }    
	        }

		}
		public void insertDate() throws InterruptedException {
			driver.findElement(calender).click();
			System.out.println("Calender Clicked");
		
			 WebElement yearElement = driver.findElement(By.xpath("//span[@class='year']"));
		     yearElement.click();
		     
		     System.out.println("Year Clicked");
		        // Select the year, month, and day values
		 //   selectValue(yearElement, "2023");
			 //   WebElement monthElement = driver.findElement(By.xpath("//span[@class='month']"));
		    
		    WebElement monthElement = driver.findElement(By.xpath("//span[contains(text(),'Jan')]"));
		    monthElement.click();
	
		    selectValue(monthElement, "March");
		    System.out.println("Month Clicked");
		    WebElement dayElement = driver.findElement(By.xpath("//td[contains(@class,'active')]"));
		    dayElement.click();
	
		
			
		}
		
		private static void selectValue(WebElement element, String value) throws InterruptedException {
	        // Click on the dropdown list to open it
			Thread.sleep(3000);
	        
	       
	        List<WebElement> options = element.findElements(By.xpath("//span[contains(text(),'2023')]"));

	        // Loop through the options and select the one that matches the value
	        for (WebElement option : options) {
	            if (option.getText().equals(value)) {
	                option.click();
	                break;
	            }
	        }
		}
		public void insertphone() {
			driver.findElement(userPhoneNumber).sendKeys("123456789");
		}
		public void userIdentity() {
			driver.findElement(userIdentity).click();
		}
		public void clicksubmit() {
			driver.findElement(submit).click();
		}
		public void clickSave() {
			driver.findElement(save).click();
		}
}
